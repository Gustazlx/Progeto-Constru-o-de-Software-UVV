document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.querySelector('form');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    loginForm.appendChild(messageDiv);
  
    // Lista de usuários válidos
    const validUsers = [
      { email: 'cooperativa@gmail.com', password: '123456' },
      { email: 'instituicao@gmail.com', password: '123456' }, // Novo usuário
    ];
  
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      messageDiv.textContent = '';
      messageDiv.className = 'message';
  
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('senha').value.trim();
  
      // Verifica se existe um usuário com o email e senha fornecidos
      const userFound = validUsers.find(user => user.email === email && user.password === password);
  
      if (userFound) {
        messageDiv.textContent = 'Login bem-sucedido! Bem-vindo!';
        messageDiv.classList.add('text-success');
        window.location.href = "telaprincipal.html";
      } else {
        messageDiv.textContent = 'Email ou senha incorretos. Tente novamente.';
        messageDiv.classList.add('text-danger');
      }
  
      // Limpar campo de senha após tentativa
      document.getElementById('senha').value = '';
    });
  });