#include <stdio.h>
#include <stdlib.h>

int main()
{
    int senha;

    printf("DIGITE A SENHA (XXXX):");
    scanf("%i", &senha);

    if(senha < 1000 || senha > 9999){
        printf("ERRO: Senha maior ou menor que 4 digitos");
    }
    else{
        if(senha % 2 != 0 && senha % 17 == 0){
            printf("Senha Criptografia: Forte");
        }
        else{
            printf("Senha Criptografia: Fraca");
        }
    }

    return 0;
}
