#include <stdio.h>
#include <stdlib.h>

int main()
{
    float preco, total;
    int quantidade;

    printf("DADPS DA MERCADORIA: \n");
    printf("PRECO: R$ "); scanf("%f", &preco);
    printf("Quantidade (Unidade): "); scanf("%i", &quantidade);

    total = preco * quantidade;

    if(total > 1000.00){
        total  = total - 0.03 * total;

    }

    printf("Total a pagar (-3%% OFF): R$ %.2f \n", total);

    return 0;
}
