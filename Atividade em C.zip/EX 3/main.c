#include <stdio.h>
#include <stdlib.h>

int main()
{
    float vreajustado, preco, reajuste;
    int selecao;

    printf("DIGITE O PRECO: R$ "); scanf("%f", &preco);
    printf("DIGITE O REAJUSTE (%%) : "); scanf("%f", &reajuste);

    printf("DIGITE (1) PARA ACRECIMO \n");
    printf("DIGITE (2) PARA DESCONTO \n");
    scanf("%i", &selecao);

    if(selecao != 1 && selecao != 2){
        printf("ERRO: Selecao invalida (somente 1 e 2)");
    }
    else{
        if(selecao == 1){
            vreajustado = preco + (preco * reajuste / 100);
            printf("O Valor reajustado com acrecimo e : R$ %.2f", vreajustado);
        }
        else{
            if(selecao == 2){
                vreajustado = preco - (preco *reajuste / 100);
            printf("O Valor reajustado com desconto e : R$ %.2f", vreajustado);
            }
        }
    }



    return 0;
}
